# 50.042 FCS Lab 6 template
# Year 2021

import math
import primes


def baby_step(alpha, beta, p, fname):
    pass


def giant_step(alpha, p, fname):
    pass


def baby_giant(alpha, beta, p):
    pass


if __name__ == "__main__":
    """
    test 1
    My private key is:  264
    Test other private key is:  7265
    """
    p = 17851
    alpha = 17511
    A = 2945
    B = 11844
    sharedkey = 1671
    a = baby_giant(alpha, A, p)
    b = baby_giant(alpha, B, p)
    guesskey1 = primes.square_multiply(A, b, p)
    guesskey2 = primes.square_multiply(B, a, p)
    print("Guess key 1:", guesskey1)
    print("Guess key 2:", guesskey2)
    print("Actual shared key :", sharedkey)
